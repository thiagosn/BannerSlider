<?php
namespace ThreeCon\BannerSlider\Ui\DataProvider\Banner;

use Magento\Ui\DataProvider\AbstractDataProvider;
use ThreeCon\BannerSlider\Model\ResourceModel\Banner\CollectionFactory;
use Magento\Framework\App\Filesystem\DirectoryList;
use Magento\Framework\UrlInterface;

class FormDataProvider extends AbstractDataProvider
{
    protected $loadedData;
    protected $urlBuilder;

    public function __construct(
        $name,
        $primaryFieldName,
        $requestFieldName,
        CollectionFactory $collectionFactory,
        UrlInterface $urlBuilder,
        array $meta = [],
        array $data = []
    ) {
        $this->collection = $collectionFactory->create();
        $this->urlBuilder = $urlBuilder;
        parent::__construct($name, $primaryFieldName, $requestFieldName, $meta, $data);
    }

    public function getData()
    {
        if (isset($this->loadedData)) {
            return $this->loadedData;
        }

        $items = $this->collection->getItems();
        foreach ($items as $banner) {
            $data = $banner->getData();

            // trata imagem para exibir no form
            if ($banner->getImagem()) {
                $imageUrl = $this->urlBuilder->getBaseUrl(['_type' => UrlInterface::URL_TYPE_MEDIA]) . 'banners/' . $banner->getImagem();
                $data['imagem'] = [[
                    'name' => $banner->getImagem(),
                    'url' => $imageUrl,
                ]];
            }

            $this->loadedData[$banner->getId()] = $data;
        }

        return $this->loadedData;
    }
}
