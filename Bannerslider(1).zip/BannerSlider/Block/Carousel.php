<?php
namespace ThreeCon\BannerSlider\Block;

use Magento\Framework\View\Element\Template;
use ThreeCon\BannerSlider\Model\ResourceModel\Banner\CollectionFactory;
use Magento\Framework\UrlInterface;

class Carousel extends Template
{
    protected $collectionFactory;
    protected $urlBuilder;

    public function __construct(
        Template\Context $context,
        CollectionFactory $collectionFactory,
        UrlInterface $urlBuilder,
        array $data = []
    ) {
        $this->collectionFactory = $collectionFactory;
        $this->urlBuilder = $urlBuilder;
        parent::__construct($context, $data);
    }

    public function getBannerCollection()
    {
        return $this->collectionFactory->create()
            ->addFieldToFilter('ativo', 1)
            ->setOrder('ordem', 'ASC');
    }

    public function getMediaUrl()
    {
        return $this->urlBuilder->getBaseUrl(['_type' => UrlInterface::URL_TYPE_MEDIA]);
    }
}
