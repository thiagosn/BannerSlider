<?php
namespace ThreeCon\BannerSlider\Controller\Adminhtml\Banner;

use Magento\Backend\App\Action;
use ThreeCon\BannerSlider\Model\BannerFactory;
use Magento\Framework\Controller\ResultFactory;
use Magento\Ui\Component\MassAction\Filter;
use ThreeCon\BannerSlider\Model\ResourceModel\Banner\CollectionFactory;

class MassDelete extends Action
{
    const ADMIN_RESOURCE = 'ThreeCon_BannerSlider::banners';

    protected $filter;
    protected $collectionFactory;

    public function __construct(
        Action\Context $context,
        Filter $filter,
        CollectionFactory $collectionFactory
    ) {
        parent::__construct($context);
        $this->filter = $filter;
        $this->collectionFactory = $collectionFactory;
    }

    public function execute()
    {
        try {
            $collection = $this->filter->getCollection($this->collectionFactory->create());
            $deleted = 0;

            foreach ($collection as $item) {
                $item->delete();
                $deleted++;
            }

            if ($deleted > 0) {
                $this->messageManager->addSuccessMessage(__('Um total de %1 banner(s) foi excluído.', $deleted));
            }
        } catch (\Exception $e) {
            $this->messageManager->addErrorMessage(__('Erro: %1', $e->getMessage()));
        }

        return $this->resultFactory->create(ResultFactory::TYPE_REDIRECT)->setPath('*/*/');
    }
}
