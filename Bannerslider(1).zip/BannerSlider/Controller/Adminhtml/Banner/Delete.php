<?php
namespace ThreeCon\BannerSlider\Controller\Adminhtml\Banner;

use Magento\Backend\App\Action;
use Magento\Framework\Controller\Result\RedirectFactory;
use ThreeCon\BannerSlider\Model\BannerFactory;

class Delete extends Action
{
    protected $bannerFactory;
    protected $resultRedirectFactory;

    public function __construct(
        Action\Context $context,
        BannerFactory $bannerFactory,
        RedirectFactory $resultRedirectFactory
    ) {
        parent::__construct($context);
        $this->bannerFactory = $bannerFactory;
        $this->resultRedirectFactory = $resultRedirectFactory;
    }

    public function execute()
    {
        $id = $this->getRequest()->getParam('banner_id');
        $resultRedirect = $this->resultRedirectFactory->create();

        if ($id) {
            try {
                $model = $this->bannerFactory->create();
                $model->load($id);
                if ($model->getId()) {
                    $model->delete();
                    $this->messageManager->addSuccessMessage(__('Banner excluído com sucesso.'));
                } else {
                    $this->messageManager->addErrorMessage(__('Banner não encontrado.'));
                }
            } catch (\Exception $e) {
                $this->messageManager->addErrorMessage(__('Erro ao excluir o banner: ') . $e->getMessage());
            }
        }

        return $resultRedirect->setPath('*/*/');
    }
}
