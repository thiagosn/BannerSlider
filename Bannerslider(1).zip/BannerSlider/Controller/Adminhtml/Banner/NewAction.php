<?php

namespace ThreeCon\BannerSlider\Controller\Adminhtml\Banner;

class NewAction extends \Magento\Backend\App\Action
{
    public function execute()
    {
        $this->_forward('edit');
    }
}
