<?php

namespace ThreeCon\BannerSlider\Controller\Adminhtml\Banner;

use Magento\Backend\App\Action;
use Magento\Backend\App\Action\Context;
use ThreeCon\BannerSlider\Model\BannerFactory;
use Magento\Framework\App\Filesystem\DirectoryList;

class Save extends Action
{
    protected $bannerFactory;
    protected $directoryList;

    public function __construct(Context $context, BannerFactory $bannerFactory, DirectoryList $directoryList)
    {
        parent::__construct($context);
        $this->bannerFactory = $bannerFactory;
        $this->directoryList = $directoryList;
    }

    public function execute()
    {
        $data = $this->getRequest()->getPostValue();

        if ($data) {
            $id = $this->getRequest()->getParam('id');
            $model = $this->bannerFactory->create();

            if ($id) {
                $model->load($id);
            }

            $model->setData($data);

            // Gerenciar imagem
            if (isset($data['imagem'][0]['name']) && isset($data['imagem'][0]['url'])) {
                $model->setImagem('bannerslider/' . $data['imagem'][0]['name']);
            }

            try {
                $model->save();
                $this->messageManager->addSuccessMessage(__('Banner salvo com sucesso.'));
                return $this->_redirect('*/*/');
            } catch (\Exception $e) {
                $this->messageManager->addErrorMessage(__('Erro ao salvar o banner: ') . $e->getMessage());
                return $this->_redirect('*/*/edit', ['id' => $id]);
            }
        }

        return $this->_redirect('*/*/');
    }
}
