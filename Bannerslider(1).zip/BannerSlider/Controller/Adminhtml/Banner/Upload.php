<?php

namespace ThreeCon\BannerSlider\Controller\Adminhtml\Banner;

use Magento\Backend\App\Action;
use Magento\MediaStorage\Model\File\UploaderFactory;
use Magento\Framework\Filesystem;
use Magento\Framework\App\Filesystem\DirectoryList;

class Upload extends Action
{
    protected $uploaderFactory;
    protected $filesystem;

    public function __construct(
        Action\Context $context,
        UploaderFactory $uploaderFactory,
        Filesystem $filesystem
    ) {
        parent::__construct($context);
        $this->uploaderFactory = $uploaderFactory;
        $this->filesystem = $filesystem;
    }

    public function execute()
    {
        try {
            $uploader = $this->uploaderFactory->create(['fileId' => 'imagem']);
            $uploader->setAllowedExtensions(['jpg', 'jpeg', 'gif', 'png']);
            $uploader->setAllowRenameFiles(true);
            $uploader->setFilesDispersion(false);

            $mediaDirectory = $this->filesystem->getDirectoryRead(DirectoryList::MEDIA)->getAbsolutePath('bannerslider');

            if (!is_dir($mediaDirectory)) {
                mkdir($mediaDirectory, 0755, true);
            }

            $result = $uploader->save($mediaDirectory);

            $result['url'] = $this->_url->getBaseUrl(['_type' => \Magento\Framework\UrlInterface::URL_TYPE_MEDIA]) . 'bannerslider/' . $result['file'];

            return $this->getResponse()->representJson(
                json_encode($result)
            );

        } catch (\Exception $e) {
            return $this->getResponse()->setBody(json_encode(['error' => $e->getMessage(), 'errorcode' => $e->getCode()]));
        }
    }
}
