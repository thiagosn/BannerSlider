<?php
namespace ThreeCon\BannerSlider\Controller\Adminhtml\Banner;

use Magento\Backend\App\Action;
use Magento\Framework\Controller\ResultFactory;
use Magento\Ui\Component\MassAction\Filter;
use ThreeCon\BannerSlider\Model\ResourceModel\Banner\CollectionFactory;

class MassDisable extends Action
{
    const ADMIN_RESOURCE = 'ThreeCon_BannerSlider::banners';

    protected $filter;
    protected $collectionFactory;

    public function __construct(
        Action\Context $context,
        Filter $filter,
        CollectionFactory $collectionFactory
    ) {
        parent::__construct($context);
        $this->filter = $filter;
        $this->collectionFactory = $collectionFactory;
    }

    public function execute()
    {
        $collection = $this->filter->getCollection($this->collectionFactory->create());
        $updated = 0;

        foreach ($collection as $banner) {
            $banner->setAtivo(0);
            $banner->save();
            $updated++;
        }

        if ($updated > 0) {
            $this->messageManager->addSuccessMessage(__('Um total de %1 banner(s) foi inativado.', $updated));
        }

        return $this->resultFactory->create(ResultFactory::TYPE_REDIRECT)->setPath('*/*/');
    }
}
