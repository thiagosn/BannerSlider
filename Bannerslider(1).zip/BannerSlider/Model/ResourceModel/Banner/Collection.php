<?php
namespace ThreeCon\BannerSlider\Model\ResourceModel\Banner;

use Magento\Framework\Model\ResourceModel\Db\Collection\AbstractCollection;

class Collection extends AbstractCollection
{
    protected $_idFieldName = 'banner_id';
    protected $_eventPrefix = 'threecon_banner_collection';
    protected $_eventObject = 'banner_collection';

    protected function _construct()
    {
        $this->_init(
            \ThreeCon\BannerSlider\Model\Banner::class,
            \ThreeCon\BannerSlider\Model\ResourceModel\Banner::class
        );
    }
}
